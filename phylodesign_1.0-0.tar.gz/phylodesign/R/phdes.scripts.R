###############################################################################
#' compute the power in differentiating H0: acute to acute is <10\% vs H0: acute to acute is >40\% with the linkage approach
#' 
#' This script varies the probability that HIV+ individuals consent to participation in the phylogenetic study at HCC
#' @param p.phylosignal				Probability that a true (potentially indirect) transmission is identified with a phylogenetic method. 
#' @param p.nocontam				Frequency with which transmissions occur within the community
#' @param p.prev.instudy.clu.armC	Probability that HIV+ individuals visit an HCC in arm C (sensitivity analysis).
#' @param opt.pooled				Pooling option for power analysis
#' @param opt.sampling				Sampling option for trial
prj.popart.powercalc_link_consenting<- function(p.phylosignal=0.7,p.nocontam=0.85, p.prev.instudy.clu.armC= 0.2, opt.pooled= "no pooling", opt.sampling= "PC and HCC")
{
	require(binom)
	require(phylodesign)
	my.mkdir(DATA,"popartpowercalc")
	dir.name<- paste(DATA,"popartpowercalc",sep='/')	
	resume<- 0
	verbose<- 1
	plot.increment<- 0.05
	
	m.type		<- "Acute"	
	cohort.size	<- 2500
	pc24.size	<- 6000
	cohort.dur	<- 3	
	test.prop0	<- 0.10
	test.prop1	<- 0.4
	test.alpha	<- 0.05		
	pooled.n	<- 1
	opt.pooled	<- "no pooling"#"pooled across trial"#"no pooling"#"pooled across ZA"#"pooled across trial"#"no pooling"
	#opt.sampling<- "PC and HCC"#"only HCC"#"PC and HCC"
	opt.power<-	"All"	
	if(!opt.pooled%in%c("pooled across country","pooled across ZA","pooled across SA","pooled across trial","no pooling"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	if(!opt.power%in%c("All","PonlyPC","IonlyPC","PonlyPCandIonlyPC"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	cat(paste("\ncohort.size",cohort.size))
	cat(paste("\ncohort.dur",cohort.dur))
	cat(paste("\ntest.prop0",test.prop0))
	cat(paste("\ntest.prop1",test.prop1))
	cat(paste("\ntest.alpha",test.alpha))	
	cat(paste("\np.nocontam",p.nocontam))
	cat(paste("\np.prev.instudy.clu.armC",p.prev.instudy.clu.armC))
	cat(paste("\npooled.n",pooled.n))
	cat(paste("\nopt.pooled",opt.pooled))
	cat(paste("\nopt.power",opt.power))
	cat(paste("\nopt.sampling",opt.sampling))
	
	sites<-	popart.getdata.randomized.arm( pooled.n )
	sites<-	popart.getdata.randomized.n(sites, cohort.size, cohort.dur)
	print(sites)
	###############################################################################
	#vary %consenting in HCC
	###############################################################################
	cat("\ncompute sampled transmissions for %consenting")
	s.consent<- seq(0.5,0.75,plot.increment)		
	x2i<- sapply(s.consent,function(x)
			{
				p.lab			<- 0.9			
				p.consent.coh	<- 0.9
				p.consent.clu	<- x
				p.vhcc.prev.AB<- 0.95
				p.vhcc.inc.AB<- 0.8
				p.vhcc.prev.C<- p.prev.instudy.clu.armC
				p.vhcc.inc.C<- p.vhcc.prev.C/2
				
				popart.get.sampled.transmissions(	sites, 
						opt.sampling,
						p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
						consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab, p.community=p.nocontam
				)																				
			})
	colnames(x2i)<- s.consent
	
	cat("\ncomputed linked transmissions")
	x2i<- phdes.get.linked.transmissions(x2i,p.phylosignal)
#print(x2i)
#stop()
	cat("\npool linked transmissions")
	print(sites)
	tmp		<- popart.pool(sites, x2i, method=opt.pooled)
	x2i		<- tmp[["transm"]]
	idx.A	<- tmp[["idx.A"]]
	idx.B	<- tmp[["idx.B"]]
	idx.C	<- tmp[["idx.C"]]
#print(x2i); print(idx.A); print(idx.B); print(idx.C)	
#stop()	
	cat("\ncompute power for dectecting differences in sampled acute to acute transmissions")
	confint.lw			<- lapply(	list(idx.A,idx.B,idx.C),	
									function(arm)	phdes.binom.power(	x2i[arm,,drop=0], round(x2i[arm,,drop=0]*test.prop0), test.prop0, test.prop1, test.alpha, verbose=0, method.pw="cloglog", method.ci="asymptotic")[["conf"]]		
									)
	names(confint.lw)	<- c("A","B","C")
	tmp					<- lapply(	list(idx.A,idx.B,idx.C),
									function(arm)	phdes.binom.power(	x2i[arm,,drop=0], round(x2i[arm,,drop=0]*test.prop1), test.prop0, test.prop1, test.alpha, verbose=0, method.pw="cloglog", method.ci="asymptotic")
									)
	confint.hg			<- lapply(tmp, function(x) x$conf	)							
	is.conf.hg			<- lapply(tmp, function(x) x$is.conf	)
	power.hg			<- lapply(tmp, function(x) x$power	)
	names(confint.hg)	<- c("A","B","C")
	names(is.conf.hg)	<- c("A","B","C")
	names(power.hg)		<- c("A","B","C")
	
	
	if(p.nocontam>=0.85)	
		cols<- c("deepskyblue","dodgerblue4")
	else					
		cols<- c("firebrick1","firebrick4")
	
	#plot power
	f.name<- paste(dir.name,paste("CFLINK_consent",p.nocontam,"phsig",p.phylosignal,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')	
	cat(paste("\nplot power to\n",f.name))
	pdf(paste(f.name),version="1.4",width=6,height=6)
	phdes.plot.power(	power.hg[["A"]], power.hg[["C"]], is.conf.hg[["A"]], is.conf.hg[["C"]],
						xlab="% consenting to ph study at HCC", 
						ylab=paste("power to distinguish acute < ",test.prop0*100,"% vs > ",test.prop1*100,"%\n",opt.pooled,sep=''),
						legend.txt=c("arm A","arm C",paste("contamination",(1-p.nocontam)*100,"%, linked to HCC/C",p.prev.instudy.clu.armC*100,"%")),
						cols=cols,
						legend.loc="bottomright", 
						verbose= 0	)
	dev.off()
	
	#plot conf intervals
	lapply(names(confint.hg),function(arm)
			{
				f.name<- paste(dir.name,paste("CFLINK_consent",p.nocontam,"phsig",p.phylosignal,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,arm,"confint",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
				cat(paste("\nplot binomial confidence intervals to\n",f.name))
				pdf(paste(f.name),version="1.4",width=6,height=6)
				phdes.plot.confint(	rep(test.prop0,nrow(confint.lw[[arm]])), rep(test.prop1,nrow(confint.lw[[arm]])),
						confint.lw[[arm]], confint.hg[[arm]],			
						xlab="% consenting to ph study at HCC",
						ylab=paste("estimated proportion acute to acute transmission\n arm",arm,",",opt.pooled),
						legend.loc="topright",
						legend.txt=c(paste("true prop",test.prop0*100,"%",sep=' '), paste("true prop",test.prop1*100,"%",sep=' ')),
						cols=cols		)													
				dev.off()
			})
		
	f.name<- paste(dir.name,paste("CFLINK_consent",p.nocontam,"phsig",p.phylosignal,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".R",sep='_'),sep='/')
	cat(paste("\nsave R objects to\n",f.name))
	save(sites, x2i, idx.A, idx.B, idx.C, power.hg, is.conf.hg, confint.lw, confint.hg, file=f.name)
	stop()													
}
###############################################################################
#' compuare the power in differentiating H0: acute to acute is <10\% vs H0: acute to acute is >40\% between the tipc cluster approach and the linkage approach
#' 
#' This script varies the probability that a true (potentially indirect) transmission is identified with a phylogenetic method.
#' @param p.nocontam				Frequency with which transmissions occur within the community
#' @param p.prev.instudy.clu.armC	Probability that HIV+ individuals visit an HCC in arm C (sensitivity analysis).
#' @param opt.pooled				Pooling option for power analysis
#' @param opt.sampling				Sampling option for trial
prj.popart.powercalc_cmp_link_tipc<- function(p.nocontam=0.85, p.prev.instudy.clu.armC= 0.2, opt.pooled= "no pooling", opt.sampling= "PC and HCC")
{
	require(binom)
	require(phylodesign)
	my.mkdir(DATA,"popartpowercalc")
	dir.name<- paste(DATA,"popartpowercalc",sep='/')	
	resume<- 0
	verbose<- 1
	plot.increment<- 0.05
	
	m.type<- "Acute"	
	cohort.size	<- 2500
	pc24.size	<- 6000
	cohort.dur	<- 3	
	test.prop0	<- 0.1
	test.prop1	<- 0.4
	test.alpha	<- 0.05		
	
	pooled.n<- 500
	#opt.pooled<- "pooled across ZA"#"pooled across trial"#"no pooling"
	#opt.sampling<- "PC and HCC"#"only HCC"#"PC and HCC"
	opt.power<-	"All"
	###############################################################################
	#set arguments
	###############################################################################	
	if(!opt.pooled%in%c("pooled across country","pooled across ZA","pooled across SA","pooled across trial","no pooling"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	if(!opt.power%in%c("All","PonlyPC","IonlyPC","PonlyPCandIonlyPC"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	debug<- 0
	
	sites<-	popart.getdata.randomized.arm( pooled.n, rtn.fixed= debug )
	sites<-	popart.getdata.randomized.n(sites, cohort.size, cohort.dur, rtn.exp= debug)
	#print(sites)
	data("popart.tipcp.highacute")
	data("popart.tipcp.lowacute")	
	#fixed parameters here:
	p.lab			<- 0.9			
	p.consent.coh	<- 0.9
	p.consent.clu	<- 0.5
	p.vhcc.prev.AB	<- 0.95
	p.vhcc.inc.AB	<- 0.8
	p.vhcc.prev.C	<- p.prev.instudy.clu.armC
	p.vhcc.inc.C	<- p.vhcc.prev.C/2	
	if(0)
	{
		p.prev.instudy.clu.armC <- 1
		p.lab			<- 1			
		p.consent.coh	<- 1
		p.consent.clu	<- 1
		p.vhcc.prev.AB	<- 1
		p.vhcc.inc.AB	<- 1
		p.vhcc.prev.C	<- 1
		p.vhcc.inc.C	<- 1
		p.nocontam		<- 1
	}
	
	cat(paste("\ncohort.size",cohort.size))
	cat(paste("\ncohort.dur",cohort.dur))
	cat(paste("\ntest.prop0",test.prop0))
	cat(paste("\ntest.prop1",test.prop1))
	cat(paste("\ntest.alpha",test.alpha))	
	cat(paste("\np.nocontam",p.nocontam))
	cat(paste("\np.prev.instudy.clu.armC",p.prev.instudy.clu.armC))
	cat(paste("\npooled.n",pooled.n))
	cat(paste("\nopt.pooled",opt.pooled))
	cat(paste("\nopt.power",opt.power))
	cat(paste("\nopt.sampling",opt.sampling))	
	###############################################################################
	#vary p.phylosignal with link approach
	###############################################################################
	cat("\ncompute sampled transmissions for p.phylosignal with link approach")	
	p.phylosignal<- seq(0.3,1,plot.increment)		
	x2i<- sapply(p.phylosignal,function(x)
			{				
				x2i<- popart.get.sampled.transmissions(	sites, 
														opt.sampling,
														p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
														consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab, p.community=p.nocontam,
														rtn.int=!debug
														)
				x2i<- phdes.get.linked.transmissions(x2i,x, rtn.exp=debug)
				x2i
			})
	colnames(x2i)<- p.phylosignal
	###############################################################################
	#compute acute to acute with tipc approach
	###############################################################################
	cat("\ncompute sampled acute to acute transmissions with tipc approach")
	tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.highacute,1-p.nocontam)
	a2a.hg			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
														p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
														consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
														rtn.int= !debug)
	tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.lowacute,1-p.nocontam)
	a2a.lw			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
														p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
														consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
														rtn.int= !debug)																
	x2i.lw	<- as.matrix(a2a.lw["x2i.s",])
	i2i.lw	<- as.matrix(a2a.lw["i2i.s",])	
	x2i.hg	<- as.matrix(a2a.hg["x2i.s",])
	i2i.hg	<- as.matrix(a2a.hg["i2i.s",])
	###############################################################################
	#pool transmissions
	###############################################################################	
	cat(paste("\npool transmissions",opt.pooled))
	x2i.lw						<- 		popart.pool(sites, x2i.lw, method=opt.pooled)[["transm"]]
	i2i.lw						<- 		popart.pool(sites, i2i.lw, method=opt.pooled)[["transm"]]
	x2i.hg						<- 		popart.pool(sites, x2i.hg, method=opt.pooled)[["transm"]]
	i2i.hg						<- 		popart.pool(sites, i2i.hg, method=opt.pooled)[["transm"]]		
	g(x2i, idx.A, idx.B, idx.C)	%<-%	popart.pool(sites, x2i, method=opt.pooled)
	
	#compute test.biased.H0 as fraction over means to see a pattern	
	test.biased.H0		<- apply(i2i.lw,2,mean)/apply(x2i.lw,2,mean)	
	test.biased.H1		<- apply(i2i.hg,2,mean)/apply(x2i.hg,2,mean)	
	test.biased.H1.arm	<- lapply(	list(idx.A, idx.B, idx.C),
									function(arm)	apply(i2i.hg[arm,,drop=0],2,mean)/apply(x2i.hg[arm,,drop=0],2,mean)
									)				
	test.biased.H0.arm	<- lapply(	list(idx.A, idx.B, idx.C),
									function(arm)	apply(i2i.lw[arm,,drop=0],2,mean)/apply(x2i.lw[arm,,drop=0],2,mean)
									)
	names(test.biased.H0.arm)<- c("A","B","C")
	names(test.biased.H1.arm)<- c("A","B","C")										
	###############################################################################
	#plot number of acute to acute transmissions under high scenario
	#adjust for sampling bias
	###############################################################################
	cat("\nplot number of acute to acute transmissions under high scenario\nadjust for sampling bias")
	f.name	<- paste(dir.name,paste("VARYLINKAGE_LINK_a2a_nocontam",p.nocontam,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
	cat(paste("\nplot to\n",f.name))
	pdf(paste(f.name),version="1.4",width=6,height=6)
	par(mar=c(5,5.5,0.5,2))
	ylim	<- range(sapply(test.biased.H1.arm, function(x)	range(round(x2i*x)) ))
	plot(1,1,type='n',xlim=range(p.phylosignal),ylim=ylim,xlab="% linked w phylogenetic method",ylab=paste("acute 2 acute, high scenario\n",opt.pooled))
	lines(p.phylosignal, apply(round(x2i*test.biased.H1),2,mean))
	abline(h=apply(i2i.hg,2,mean), lty=2)		
	lines(p.phylosignal, apply(round(x2i[idx.A,,drop=0]*test.biased.H1.arm[["A"]]),2,mean),col="red")
	abline(h=apply(i2i.hg[idx.A,,drop=0],2,mean), lty=2,col="red")
	lines(p.phylosignal, apply(round(x2i[idx.B,,drop=0]*test.biased.H1.arm[["B"]]),2,mean),col="green")
	abline(h=apply(i2i.hg[idx.B,,drop=0],2,mean), lty=2,col="green")	
	lines(p.phylosignal, apply(round(x2i[idx.C,,drop=0]*test.biased.H1.arm[["C"]]),2,mean),col="blue")
	abline(h=apply(i2i.hg[idx.C,,drop=0],2,mean), lty=2,col="blue")
	legend("topleft",fill=c("black","red","green","blue"),legend=c("overall","arm A","arm B","arm C"),bty='n',border=NA)
	legend("topright",lty=c(1,2),legend=c("linked","tipc"),bty='n')
	dev.off()
	
	stop()													
}
###############################################################################
#' compute the power in differentiating H0: acute to acute is <10\% vs H0: acute to acute is >40\% with the tipc cluster approach
#' 
#' This script varies the probability that HIV+ individuals consent to participation in the phylogenetic study at HCC
#' @param p.phylosignal				Probability that a true (potentially indirect) transmission is identified with a phylogenetic method. (Here not used)
#' @param p.nocontam				Frequency with which transmissions occur within the community
#' @param opt.pooled				Pooling option for power analysis
#' @param opt.sampling				Sampling option for trial
prj.popart.powercalc_tipc_consenting<- function(p.phylosignal=0.7,p.nocontam=0.85, opt.pooled= "no pooling", opt.sampling= "PC and HCC")
{
	require(binom)
	require(phylodesign)
	my.mkdir(DATA,"popartpowercalc")
	dir.name<- paste(DATA,"popartpowercalc",sep='/')	
	resume<- 0
	verbose<- 0
	plot.increment<- 0.05
	
	m.type		<- "Acute"	
	cohort.size	<- 2500
	pc24.size	<- 6000
	cohort.dur	<- 3	
	test.prop0	<- 0.10
	test.prop1	<- 0.4
	test.alpha	<- 0.05		 
	debug		<- 0
	pooled.n	<- 100
	opt.pooled	<- "no pooling"#"pooled across ZA"#"pooled across trial"#"no pooling"
	opt.pooled	<- "pooled across SA"
	opt.sampling<- "PC and HCC"#"only HCC"	#"PC and HCC"	#
	#opt.sampling<- "PC after yr 1 and HCC"
	#opt.sampling<- "PC only incident and HCC"
	opt.power	<-	"All"
	if(!opt.pooled%in%c("pooled across country","pooled across ZA","pooled across SA","pooled across trial","no pooling"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	if(!opt.power%in%c("All","PonlyPC","IonlyPC","PonlyPCandIonlyPC"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	cat(paste("\ncohort.size",cohort.size))
	cat(paste("\ncohort.dur",cohort.dur))
	cat(paste("\ntest.prop0",test.prop0))
	cat(paste("\ntest.prop1",test.prop1))
	cat(paste("\ntest.alpha",test.alpha))	
	cat(paste("\np.nocontam",p.nocontam))
	cat(paste("\npooled.n",pooled.n))
	cat(paste("\nopt.pooled",opt.pooled))
	cat(paste("\nopt.power",opt.power))
	cat(paste("\nopt.sampling",opt.sampling))
	
	sites<-	popart.getdata.randomized.arm( pooled.n, rtn.fixed=debug )
	sites<-	popart.getdata.randomized.n(sites, cohort.size, cohort.dur, rtn.exp=debug)
	data("popart.tipcp.highacute")
	data("popart.tipcp.lowacute")
		
	###############################################################################
	#vary %consenting in HCC
	###############################################################################
	cat("\ncompute sampled acute to acute transmissions for %consenting")
	p.vhcc.prev.Cs<- seq(0.15,0.4,plot.increment)
	p.consent.clus<- seq(0.5,0.8,plot.increment)
	out<- lapply(p.vhcc.prev.Cs,function(x)
			{
				inc<- lapply(p.consent.clus,function(y)
						{
							p.lab			<- 0.9		
							p.consent.coh	<- 0.9
							p.consent.clu	<- y
							p.vhcc.prev.AB	<- 0.95
							p.vhcc.inc.AB	<- 0.8
							p.vhcc.prev.C	<- x
							p.vhcc.inc.C	<- x/2
							tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.highacute,1-p.nocontam)
							a2a.hg			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
																				p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																				consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
																				rtn.int=!debug)
							tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.lowacute,1-p.nocontam)
							a2a.lw			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
																				p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																				consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
																				rtn.int=!debug)																
							list(a2a.lw=a2a.lw, a2a.hg=a2a.hg)				
						})
				names(inc)<- p.consent.clus										
				x2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["x2i.s",])
				i2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["i2i.s",])	
				x2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["x2i.s",])
				i2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["i2i.s",])					
				# pool transmissions
				x2i.lw							<- 		popart.pool(sites, x2i.lw, method=opt.pooled)[["transm"]]
				i2i.lw							<- 		popart.pool(sites, i2i.lw, method=opt.pooled)[["transm"]]
				x2i.hg							<- 		popart.pool(sites, x2i.hg, method=opt.pooled)[["transm"]]
				g(i2i.hg, idx.A, idx.B, idx.C)	%<-% 	popart.pool(sites, i2i.hg, method=opt.pooled)
				
				test.biased.H0	<- lapply(	list(idx.A, idx.B, idx.C),
												function(arm)	apply(i2i.lw[arm,,drop=0],2,mean)/apply(x2i.lw[arm,,drop=0],2,mean)
												)
				test.biased.H1	<- lapply(	list(idx.A, idx.B, idx.C),
												function(arm)	apply(i2i.hg[arm,,drop=0],2,mean)/apply(x2i.hg[arm,,drop=0],2,mean)
												)																
				names(test.biased.H0)<- c("A","B","C")
				names(test.biased.H1)<- c("A","B","C")
				
				# compute power and confidence intervals
				conf.lw.A		<- phdes.binom.power(x2i.lw[idx.A,,drop=0], i2i.lw[idx.A,,drop=0], test.biased.H0[["A"]], test.biased.H1[["A"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				conf.lw.B		<- phdes.binom.power(x2i.lw[idx.B,,drop=0], i2i.lw[idx.B,,drop=0], test.biased.H0[["B"]], test.biased.H1[["B"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				conf.lw.C		<- phdes.binom.power(x2i.lw[idx.C,,drop=0], i2i.lw[idx.C,,drop=0], test.biased.H0[["C"]], test.biased.H1[["C"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				  				 	 
				g(conf.hg.A,is.conf.hg.A,power.hg.A)	%<-% phdes.binom.power(x2i.hg[idx.A,,drop=0], i2i.hg[idx.A,,drop=0], test.biased.H0[["A"]], test.biased.H1[["A"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
				g(conf.hg.B,is.conf.hg.B,power.hg.B)	%<-% phdes.binom.power(x2i.hg[idx.B,,drop=0], i2i.hg[idx.B,,drop=0], test.biased.H0[["B"]], test.biased.H1[["B"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
				g(conf.hg.C,is.conf.hg.C,power.hg.C)	%<-% phdes.binom.power(x2i.hg[idx.C,,drop=0], i2i.hg[idx.C,,drop=0], test.biased.H0[["C"]], test.biased.H1[["C"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
												
				tmp<- list(	i2i.hg.A= apply(i2i.hg[idx.A,,drop=0],2,mean),
							i2i.hg.B= apply(i2i.hg[idx.B,,drop=0],2,mean),
							i2i.hg.C= apply(i2i.hg[idx.C,,drop=0],2,mean),
							x2i.hg.A= apply(x2i.hg[idx.A,,drop=0],2,mean),
							x2i.hg.B= apply(x2i.hg[idx.B,,drop=0],2,mean),
							x2i.hg.C= apply(x2i.hg[idx.C,,drop=0],2,mean),
							is.conf.A= is.conf.hg.A,
							is.conf.B= is.conf.hg.B,
							is.conf.C= is.conf.hg.C,
							power.A= power.hg.A,
							power.B= power.hg.B,
							power.C= power.hg.C,
							conf.hg.A= conf.hg.A,
							conf.hg.B= conf.hg.B,
							conf.hg.C= conf.hg.C,
							conf.lw.A= conf.lw.A,
							conf.lw.B= conf.lw.B,
							conf.lw.C= conf.lw.C
							)	
				tmp
			})
	names(out)<- p.vhcc.prev.Cs
	i2i.hg			<- lapply(c("i2i.hg.A","i2i.hg.B","i2i.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]]	)	)
	names(i2i.hg)	<- c("A","B","C")
	conf.hg.u		<- lapply(c("conf.hg.A","conf.hg.B","conf.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"upper"]	)	)
	names(conf.hg.u)<- c("A","B","C")
	conf.lw.u		<- lapply(c("conf.lw.A","conf.lw.B","conf.lw.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"upper"]	)	)
	names(conf.lw.u)<- c("A","B","C")
	conf.hg.l		<- lapply(c("conf.hg.A","conf.hg.B","conf.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"lower"]	)	)
	names(conf.hg.l)<- c("A","B","C")
	conf.lw.l		<- lapply(c("conf.lw.A","conf.lw.B","conf.lw.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"lower"]	)	)
	names(conf.lw.l)<- c("A","B","C")
	
	###############################################################################
	#plot sampled a2a
	###############################################################################
	if(0)
	{
		require(fields)
		f.name<- paste(dir.name,paste("VARYCONSENT_TIPC_a2a_",p.nocontam,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
		cat(paste("\nplot a2a to\n",f.name))
		pdf(paste(f.name),version="1.4",width=12,height=6)		
		breaks		<- diff(range(c(i2i.hg[["A"]],i2i.hg[["B"]],i2i.hg[["C"]])))/50
		breaks		<- seq(min(c(i2i.hg[["A"]],i2i.hg[["B"]],i2i.hg[["C"]])),by=breaks, len=51)	
		#def.par <- par(no.readonly = TRUE)
		layout.m<- matrix(data= seq_len(3),ncol=3,nrow=1,byrow=1)
		layout(layout.m)				
		sapply(c("A","B","C"),function(arm)
			{
				if(arm!="C")
					image(main=paste("arm",arm),p.consent.clus,p.vhcc.prev.Cs,i2i.hg[[arm]], breaks=breaks, col=head( rev(gray(seq(0,.95,len=trunc(50*1.4)))), 50))
				else
					image.plot(main=paste("arm",arm),p.consent.clus,p.vhcc.prev.Cs,i2i.hg[[arm]], breaks=breaks, col=head( rev(gray(seq(0,.95,len=trunc(50*1.4)))), 50),zlim= range(i2i.hg))
			})		
		dev.off()
	}
	###############################################################################
	#plot panel of confidence intervals
	###############################################################################
	if(1)
	{
		cols<- c("deepskyblue","dodgerblue4")
		cat(paste("\nplot confidence panels\n"))
		sapply(names(conf.lw.u),function(arm)
				{
					f.name<- paste(dir.name,paste("VARYCONSENT_TIPC_confint",arm,p.nocontam,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
					cat(paste("\nplot confint",arm,"to\n",f.name))
					pdf(paste(f.name),version="1.4",width=6,height=12)
					phdes.plot.confint.panel(t(conf.lw.l[[arm]]),t(conf.lw.u[[arm]]),t(conf.hg.l[[arm]]),t(conf.hg.u[[arm]]),p.consent.clus,p.vhcc.prev.Cs,"p.vhcc.prev.Cs","p.consent.clus", cols=cols)
					dev.off()					
				})		
	}
	stop()	
}
###############################################################################
#' compute the power in differentiating H0: acute to acute is <10\% vs H0: acute to acute is >40\% with the tipc cluster approach
#' 
#' This script varies the probability that transmission occurs outside the community.
#' @param p.prev.instudy.clu.armC	Probability that HIV+ individuals visit an HCC in arm C (sensitivity analysis).
#' @param p.phylosignal				Probability that a true (potentially indirect) transmission is identified with a phylogenetic method. (Here not used)
#' @param opt.pooled				Pooling option for power analysis
#' @param opt.sampling				Sampling option for trial
prj.popart.powercalc_tipc_contam<- function(p.prev.instudy.clu.armC=0.4, p.phylosignal=0.7, opt.pooled= "no pooling", opt.sampling= "PC and HCC")
{
	require(binom)
	require(phylodesign)
	my.mkdir(DATA,"popartpowercalc")
	dir.name<- paste(DATA,"popartpowercalc",sep='/')	
	resume<- 0
	verbose<- 0
	plot.increment<- 0.05
	
	m.type<- "Acute"	
	cohort.size<- 2500
	pc24.size<- 6000
	cohort.dur<- 3	
	test.prop0<- 0.10
	test.prop1<- 0.4
	test.alpha<- 0.05		 
	debug<- 0
	pooled.n<- 1
	opt.pooled<- "pooled across T5"#"pooled across ZA"#"pooled across trial"#"no pooling"
	opt.sampling<- "PC and HCC"#"only HCC"#"PC and HCC"
	opt.power<-	"All"
	if(!opt.pooled%in%c("pooled across country","pooled across ZA","pooled across SA","pooled across trial","pooled across T5","no pooling"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	if(!opt.power%in%c("All","PonlyPC","IonlyPC","PonlyPCandIonlyPC"))
		stop("prj.popart.powercalc_medsize: unknown method to pool")
	cat(paste("\ncohort.size",cohort.size))
	cat(paste("\ncohort.dur",cohort.dur))
	cat(paste("\ntest.prop0",test.prop0))
	cat(paste("\ntest.prop1",test.prop1))
	cat(paste("\ntest.alpha",test.alpha))	
	cat(paste("\np.prev.instudy.clu.armC",p.prev.instudy.clu.armC))
	cat(paste("\npooled.n",pooled.n))
	cat(paste("\nopt.pooled",opt.pooled))
	cat(paste("\nopt.power",opt.power))
	cat(paste("\nopt.sampling",opt.sampling))
	
	sites<-	popart.getdata.randomized.arm( pooled.n, rtn.fixed=debug )
	sites<-	popart.getdata.randomized.n(sites, cohort.size, cohort.dur, rtn.exp=debug)
	data("popart.tipcp.highacute")
	data("popart.tipcp.lowacute")
	#print(sites)
	###############################################################################
	#vary %consenting in HCC
	###############################################################################
	cat("\ncompute sampled acute to acute transmissions for %contamination")
	p.nocontams		<- seq(0.5,0.95,0.1) 	
	p.consent.clus	<- seq(0.4,0.8,plot.increment)
	out<- lapply(p.nocontams,function(x)
			{
				inc	<- lapply(p.consent.clus,function(y)
						{
							p.lab			<- 0.95		
							p.consent.coh	<- 0.9
							p.consent.clu	<- y
							p.vhcc.prev.AB	<- 0.95
							p.vhcc.inc.AB	<- 0.8
							p.vhcc.prev.C	<- p.prev.instudy.clu.armC
							p.vhcc.inc.C	<- p.prev.instudy.clu.armC/2
							p.nocontam		<- x
							tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.highacute,1-p.nocontam)
							a2a.hg			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
																				p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																				consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
																				rtn.int=!debug)
							tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.lowacute,1-p.nocontam)
							a2a.lw			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, 
																				p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																				consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab,
																				rtn.int=!debug)																
							list(a2a.lw=a2a.lw, a2a.hg=a2a.hg)				
						})
				names(inc)<- p.consent.clus										
				x2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["x2i.s",])
				i2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["i2i.s",])	
				x2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["x2i.s",])
				i2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["i2i.s",])					
				# pool transmissions
				x2i.lw							<- 		popart.pool(sites, x2i.lw, method=opt.pooled)[["transm"]]
				i2i.lw							<- 		popart.pool(sites, i2i.lw, method=opt.pooled)[["transm"]]
				x2i.hg							<- 		popart.pool(sites, x2i.hg, method=opt.pooled)[["transm"]]
				g(i2i.hg, idx.A, idx.B, idx.C)	%<-% 	popart.pool(sites, i2i.hg, method=opt.pooled)
				
				test.biased.H0	<- lapply(	list(idx.A, idx.B, idx.C),
						function(arm)	apply(i2i.lw[arm,,drop=0],2,mean)/apply(x2i.lw[arm,,drop=0],2,mean)
				)
				test.biased.H1	<- lapply(	list(idx.A, idx.B, idx.C),
						function(arm)	apply(i2i.hg[arm,,drop=0],2,mean)/apply(x2i.hg[arm,,drop=0],2,mean)
				)																
				names(test.biased.H0)<- c("A","B","C")
				names(test.biased.H1)<- c("A","B","C")
				
				# compute power and confidence intervals
				conf.lw.A		<- phdes.binom.power(x2i.lw[idx.A,,drop=0], i2i.lw[idx.A,,drop=0], test.biased.H0[["A"]], test.biased.H1[["A"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				conf.lw.B		<- phdes.binom.power(x2i.lw[idx.B,,drop=0], i2i.lw[idx.B,,drop=0], test.biased.H0[["B"]], test.biased.H1[["B"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				conf.lw.C		<- phdes.binom.power(x2i.lw[idx.C,,drop=0], i2i.lw[idx.C,,drop=0], test.biased.H0[["C"]], test.biased.H1[["C"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")[["conf"]]
				
				g(conf.hg.A,is.conf.hg.A,power.hg.A)	%<-% phdes.binom.power(x2i.hg[idx.A,,drop=0], i2i.hg[idx.A,,drop=0], test.biased.H0[["A"]], test.biased.H1[["A"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
				g(conf.hg.B,is.conf.hg.B,power.hg.B)	%<-% phdes.binom.power(x2i.hg[idx.B,,drop=0], i2i.hg[idx.B,,drop=0], test.biased.H0[["B"]], test.biased.H1[["B"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
				g(conf.hg.C,is.conf.hg.C,power.hg.C)	%<-% phdes.binom.power(x2i.hg[idx.C,,drop=0], i2i.hg[idx.C,,drop=0], test.biased.H0[["C"]], test.biased.H1[["C"]], test.alpha, verbose=0, method.ci="asymptotic",method.pw="cloglog")
				
				tmp<- list(	i2i.hg.A= apply(i2i.hg[idx.A,,drop=0],2,mean),
							i2i.hg.B= apply(i2i.hg[idx.B,,drop=0],2,mean),
							i2i.hg.C= apply(i2i.hg[idx.C,,drop=0],2,mean),
							x2i.hg.A= apply(x2i.hg[idx.A,,drop=0],2,mean),
							x2i.hg.B= apply(x2i.hg[idx.B,,drop=0],2,mean),
							x2i.hg.C= apply(x2i.hg[idx.C,,drop=0],2,mean),
							is.conf.A= is.conf.hg.A,
							is.conf.B= is.conf.hg.B,
							is.conf.C= is.conf.hg.C,
							power.A= power.hg.A,
							power.B= power.hg.B,
							power.C= power.hg.C,
							conf.hg.A= conf.hg.A,
							conf.hg.B= conf.hg.B,
							conf.hg.C= conf.hg.C,
							conf.lw.A= conf.lw.A,
							conf.lw.B= conf.lw.B,
							conf.lw.C= conf.lw.C
							)	
				tmp						
			})
	names(out)<- p.nocontams
	i2i.hg			<- lapply(c("i2i.hg.A","i2i.hg.B","i2i.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]]	)	)
	names(i2i.hg)	<- c("A","B","C")
	conf.hg.u		<- lapply(c("conf.hg.A","conf.hg.B","conf.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"upper"]	)	)
	names(conf.hg.u)<- c("A","B","C")
	conf.lw.u		<- lapply(c("conf.lw.A","conf.lw.B","conf.lw.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"upper"]	)	)
	names(conf.lw.u)<- c("A","B","C")
	conf.hg.l		<- lapply(c("conf.hg.A","conf.hg.B","conf.hg.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"lower"]	)	)
	names(conf.hg.l)<- c("A","B","C")
	conf.lw.l		<- lapply(c("conf.lw.A","conf.lw.B","conf.lw.C"), function(arm)	sapply(out,function(x)		x[[arm]][,"lower"]	)	)
	names(conf.lw.l)<- c("A","B","C")		
	###############################################################################
	#plot sampled a2a
	###############################################################################
	if(1)
	{
		require(fields)
		f.name<- paste(dir.name,paste("VARYCONTAM_TIPC_a2a_visitHCC.C",p.prev.instudy.clu.armC,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
		cat(paste("\nplot a2a to\n",f.name))
		pdf(paste(f.name),version="1.4",width=12,height=6)		
		breaks		<- diff(range(unlist(i2i.hg)))/50
		breaks		<- seq(min(unlist(i2i.hg)),by=breaks, len=51)		
		#def.par <- par(no.readonly = TRUE)
		layout.m<- matrix(data= seq_len(3),ncol=3,nrow=1,byrow=1)
		layout(layout.m)				
		sapply(c("A","B","C"),function(arm)
				{
					if(arm!="C")
						image(main=paste("arm",arm),p.consent.clus,p.nocontams,i2i.hg[[arm]], breaks=breaks, col=head( rev(gray(seq(0,.95,len=trunc(50*1.4)))), 50))
					else
						image.plot(main=paste("arm",arm),p.consent.clus,p.nocontams,i2i.hg[[arm]], breaks=breaks, col=head( rev(gray(seq(0,.95,len=trunc(50*1.4)))), 50),zlim= range(i2i.hg))
				})
		dev.off()	
	}
	###############################################################################
	#plot panel of confidence intervals
	###############################################################################
	if(1)
	{
		cols<- c("deepskyblue","dodgerblue4")
		cat(paste("\nplot confidence panels\n"))
		sapply(names(conf.lw.u),function(arm)
				{
					f.name<- paste(dir.name,paste("VARYCONTAM_TIPC_confint",arm,"visitHCC.C",p.prev.instudy.clu.armC,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
					cat(paste("\nplot confint C to\n",f.name))
					pdf(paste(f.name),version="1.4",width=6,height=12)
					phdes.plot.confint.panel(t(conf.lw.l[[arm]]),t(conf.lw.u[[arm]]),t(conf.hg.l[[arm]]),t(conf.hg.u[[arm]]),p.consent.clus,p.nocontams,"p.vhcc.prev.Cs","p.nocontams", cols=cols)
					dev.off()					
				})				
	}
	stop()	
}
###############################################################################
prj.popart.tchain_test<- function()
{
	clu.clo	<- 10
	clu.n	<- clu.n.of.tchain(clu.clo)
	p.U2E	<- 0.2
	r.E2E	<- c(0.5,1,2,4)
	clu.p	<- lapply(r.E2E,function(x)
			{
				theta<- p.U2E*c(x,1)
				names(theta)<- c("E2E","U2E")				
				clu.p.of.tchain(clu.n, theta )								
			})
	#print(clu.p)
	
	#densities for given tip cluster size
	if(0)
	{
		clu.p	<- lapply(seq_along(clu.p),function(i)		
				{
					norm<- apply(clu.p[[i]],2,function(x)  sum(x,na.rm=1))
					clu.p[[i]] / matrix( rep(norm,each=nrow(clu.p[[i]])), nrow(clu.p[[i]]), ncol(clu.p[[i]]) )
				})
		print(clu.p)
		#plot
		col.idx<- 4
		clu.dens<- sapply(clu.p,function(x) x[,col.idx])
		#print(clu.dens)
		xlim<- range(c(1,col.idx))
		ylim<- range(clu.dens,na.rm=1)
		par(mar=c(4,5,1,1))
		plot(1,1,type='n',bty='n',xlim=xlim,ylim=ylim,xlab="i",ylab=expression("p("*U^i*" "*E^(n-i)*")"))
		sapply(seq_len(ncol(clu.dens)),function(j)
				{
					lines(1:col.idx, clu.dens[1:col.idx,j],lty=j)
				})
		legend("topright",lty=seq_len(ncol(clu.dens)), legend=r.E2E, bty='n')
	}
	
	#log prob of tip clusters, normalized after a closure at 'clu.clo'
	if(0)
	{
		clu.nchain	<- apply( clu.n, 2, sum )				
		clu.logp	<- sapply(seq_along(clu.p),function(i)
				{
					tmp<- apply(clu.p[[i]],2,function(x)	sum(x,na.rm=1)	)
					tmp<- tmp / clu.nchain
					log( tmp / sum(tmp) )
				})
		print(clu.logp)
		
		#plot
		xlim<- c(1,nrow(clu.logp))
		ylim<- range(clu.logp)
		plot(1,1,type='n',bty='n',xlim=xlim,ylim=ylim,xlab="number of transmissions in tip cluster",ylab=expression("log likelihood"))
		sapply(seq_len(ncol(clu.logp)),function(j)
				{
					lines(1:nrow(clu.logp), clu.logp[,j], lty=j)
				})
		legend("bottomleft",lty=seq_len(ncol(clu.logp)), legend=r.E2E, bty='n')
	}
	
	#cluster probabilities under sampling and explore loss under smaller closures
	if(0)
	{
		sampling.pa	<- c(0.05,0.1,0.2,0.3, 0.4, 0.6)
		mx.s.ntr	<- 4		
		clu.clo		<- c(6,8,10,12,14,16)
		theta		<- { tmp<- c(0.6,0.3); names(tmp)<- c("E2E","U2E"); tmp }
		
		mse<- sapply(sampling.pa, function(y)
				{
					sampling<- { tmp<- c(y,y); names(tmp)<- c("Idx","E"); tmp }									
					clu.ps	<- lapply(clu.clo,function(x)
							{
								clu.n	<- clu.n.of.tchain(x)
								clu.p	<- clu.p.of.tchain(clu.n, theta )
								clu.ps	<- clu.p.of.tchain.rnd.sampling(clu.p, sampling, mx.s.ntr, rtn.only.closure.sum=1 )
								clu.ps
							})
					clu.lps	<- clu.ps[[length(clu.ps)]]	
					mse		<- sapply(seq_along(clu.ps),function(i)
							{
								tmp<- abs(clu.ps[[i]]-clu.lps )#*( clu.ps[[i]]-clu.lps )
								sum( tmp, na.rm=1 )
							})
					names(mse)<- clu.clo
					mse
				})
		colnames(mse)<- sampling.pa
		cat("\nmean square error is\n")
		print(mse)
		
		#plot
		xlim<- range(clu.clo)
		ylim<- range(mse, na.rm=1)
		plot(1,1,type='n',bty='n',xlab="closure",ylab="total absolute error",xlim=xlim,ylim=ylim)
		sapply(seq_len(ncol(mse)),function(j)
				{
					lines(clu.clo, mse[,j],lty=j)
				})
		legend("topright",bty='n',lty=seq_len(ncol(mse)), legend=sampling.pa)
	}
	
	#cluster probabilities under sampling and explore how large tip cluster table should be
	if(0)
	{
		sampling.pa	<- c(0.05,0.1,0.2,0.3,0.4)
		mx.s.ntr	<- c(4,5,6,7,8,9)		
		clu.clo		<- 18
		theta		<- { tmp<- c(0.6,0.3); names(tmp)<- c("E2E","U2E"); tmp }
		clu.n		<- clu.n.of.tchain(clu.clo)
		clu.nchain	<- apply( clu.n, 2, sum )
		clu.p		<- clu.p.of.tchain(clu.n, theta )
		clu.p		<- apply(clu.p,2,function(x)	sum(x,na.rm=1)	) / clu.nchain
		clu.p		<- clu.p / sum( clu.p ) 
		print(clu.p)
		
		mse<- sapply(sampling.pa, function(y)
				{
					sampling<- { tmp<- c(y,y); names(tmp)<- c("Idx","E"); tmp }									
					clu.ps	<- lapply(seq_along(mx.s.ntr),function(i)
							{								
								tmp			<- clu.p.of.tipc.rnd.sampling(clu.p, sampling, mx.s.ntr[i], rtn.only.closure.sum=0 )
								c(tmp, rep(0,length(mx.s.ntr)-i))								
							})
					clu.lps	<- clu.ps[[length(clu.ps)]]	
					mse		<- sapply(seq_along(clu.ps),function(i)
							{
								tmp<- abs(clu.ps[[i]]-clu.lps )#*( clu.ps[[i]]-clu.lps )
								sum( tmp, na.rm=1 )
							})
					names(mse)<- mx.s.ntr
					mse
				})		
		colnames(mse)<- sampling.pa
		cat("\nmean square error is\n")
		print(mse)
		
		#plot
		xlim<- range(mx.s.ntr)
		ylim<- range(mse, na.rm=1)
		plot(1,1,type='n',bty='n',xlab="number of transmissions in tip cluster",ylab="total absolute error",xlim=xlim,ylim=ylim)
		sapply(seq_len(ncol(mse)),function(j)
				{
					lines(mx.s.ntr, mse[,j],lty=j)
				})
		legend("topright",bty='n',lty=seq_len(ncol(mse)), legend=sampling.pa)
	}
	
	#exp number x->E
	if(0)
	{
		print( clu.p[[1]] )
		clu.E2E<-	sapply(seq_along(clu.p),function(i)	clu.exp.X2E(clu.p[[i]])[["n.E2E"]]	)
		clu.x2E<-	sapply(seq_along(clu.p),function(i)	clu.exp.X2E(clu.p[[i]])[["n.Idx2E"]]	)
		print( clu.E2E )
		print( clu.x2E )
		#plot
		xlim<- c(1,nrow(clu.x2E))
		ylim<- range(c(0,3,clu.x2E))
		plot(1,1,type='n',bty='n',xlim=xlim,ylim=ylim,xlab="number of transmissions in tip cluster",ylab="expected Idx->E transmissions")
		sapply(seq_len(ncol(clu.x2E)),function(j)
				{
					lines(1:nrow(clu.x2E), clu.x2E[,j], lty=j)
				})
		abline(h=1,col="blue",lty=2)
		legend("bottomleft",lty=seq_len(ncol(clu.x2E)), legend=r.E2E, bty='n')
	}
	
	#simulate tip cluster
	if(0)
	{
		p.U2E		<- 0.4
		p.T2E		<- 0.1
		p.O2E		<- 0.1
		p.E2E		<- 0.4		
		theta		<- { tmp<- c(p.E2E, p.U2E, p.T2E, p.O2E); names(tmp)<- c("E2E","U2E","T2E","O2E"); tmp }
		incidence	<- 1000
		clu.simulate(incidence, clu.n, theta)
	}
	
	#simulate tip cluster under sampling
	if(0)
	{
		p.U2E		<- 0.4
		p.T2E		<- 0.1
		p.O2E		<- 0.1
		p.E2E		<- 0.4		
		theta		<- { tmp<- c(p.E2E, p.U2E, p.T2E, p.O2E); names(tmp)<- c("E2E","U2E","T2E","O2E"); tmp }
		sampling	<- { tmp<- c(0.3,0.3); names(tmp)<- c("Idx","E"); tmp }
		incidence	<- 1000		
		clu.n		<- clu.n.of.tchain(15)
		mx.s.ntr	<- ncol(clu.n)#6
		
		clu.sim		<- clu.simulate(incidence, clu.n, theta)
		print(clu.sim)
		clu.sim		<- clu.sample(clu.sim, sampling, mx.s.ntr, rtn.exp=1)		
		print(clu.sim)
		
		clu.p	<- lapply(r.E2E,function(x)
				{
					theta<- p.U2E*c(x,1)
					names(theta)<- c("E2E","U2E")				
					clu.p.of.tchain(clu.n, theta )								
				})
	}
	
	#compute expected number of x->E and E->E transmissions for sampled tip cluster, and compare pi^s as sampling varies
	if(1)
	{
		p.U2E		<- 0.4
		p.T2E		<- 0.3
		p.O2E		<- 0.3
		p.E2E		<- 0		
		theta		<- { tmp<- c(p.E2E, p.U2E, p.T2E, p.O2E); names(tmp)<- c("E2E","U2E","T2E","O2E"); tmp }
		sampling.pa	<- seq(1,1,0.05)		
		incidence	<- 1000		
		clu.n		<- clu.n.of.tchain(14)
		mx.s.ntr	<- 14
		clu.sim		<- clu.simulate(incidence, clu.n, theta)
		print(clu.sim)
		print(apply(clu.sim,1,sum))

		clu.trans	<- sapply(sampling.pa,function(x)
						{
							sampling	<- { tmp<- c(x,x); names(tmp)<- c("Idx","E"); tmp }
							clu.sim		<- clu.sample(clu.sim, sampling, rtn.exp=1)	
							clu.trans	<- clu.exp.transmissions(clu.sim, clu.n, theta, sampling, mx.s.ntr, exclude.O= 0)
							clu.trans
						})
		colnames(clu.trans)	<- sampling.pa	
		clu.E2E		<- apply(clu.trans,2,function(x)  x["E2E"]/sum(x) )		
		print(clu.trans)
		print(sum(clu.trans))
		print(clu.E2E)
	#print( clu.trans["E2E"] / sum(clu.trans) )
	}
	stop()
}
###############################################################################
prj.popart.power_test<- function()
{
	require(binom)
	require(phylodesign)
	my.mkdir(DATA,"popartpowercalc")
	dir.name<- paste(DATA,"popartpowercalc",sep='/')	
	resume<- 0
	verbose<- 1
	plot.increment<- 0.05
	
	m.type<- "Acute"	
	cohort.size<- 2500
	pc24.size<- 6000
	cohort.dur<- 3	
	test.prop0<- 0.10
	test.prop1<- 0.4
	test.alpha<- 0.05		 
	p.nocontam<- 	1	
	pooled.n<- 1
	p.prev.instudy.clu.armC<- 0.2
	opt.pooled<- "no pooling"#"pooled across ZA"#"pooled across trial"#"no pooling"
	opt.sampling<- "PC and HCC"#"only HCC"#"PC and HCC"
	opt.power<-	"All"
	
	debug<- 1	#for checking / debugging
	sites<-	popart.getdata.randomized.arm( pooled.n, rtn.fixed=debug)
	sites<-	popart.getdata.randomized.n(sites, cohort.size, cohort.dur, rtn.exp=debug)
	data("popart.tipcp.highacute")
	data("popart.tipcp.lowacute")	
	#print(sites)	
	###############################################################################
	#plot the biased proportions for baseline parameters
	###############################################################################
	cat("\nplot the biased proportions for baseline parameters")
	s.consent<- seq(0.4,0.8,0.05)		
	inc<- lapply(s.consent,function(x)
			{
				p.lab			<- 0.9		
				p.consent.coh	<- 0.9
				p.consent.clu	<- x
				p.vhcc.prev.AB	<- 0.95
				p.vhcc.inc.AB	<- 0.8
				p.vhcc.prev.C	<- p.prev.instudy.clu.armC
				p.vhcc.inc.C	<- p.prev.instudy.clu.armC#*0.9
				p.nocontam	 	<- 0.85
				tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.highacute,1-p.nocontam)
				a2a.hg			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, rtn.int=!debug,
																	p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																	consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab	)
				tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.lowacute,1-p.nocontam)
				a2a.lw			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, rtn.int=!debug,
																	p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
																	consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab	)																
				list(a2a.lw=a2a.lw, a2a.hg=a2a.hg)				
			})
	names(inc)<- s.consent
	x2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["x2i.s",])
	i2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["i2i.s",])	
	x2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["x2i.s",])
	i2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["i2i.s",])
	#print( i2i.lw )
	#print( x2i.lw )	
	# pool transmissions
	x2i.lw	<- popart.pool(sites, x2i.lw, method=opt.pooled)[["transm"]]
	i2i.lw	<- popart.pool(sites, i2i.lw, method=opt.pooled)[["transm"]]
	x2i.hg	<- popart.pool(sites, x2i.hg, method=opt.pooled)[["transm"]]
	tmp		<- popart.pool(sites, i2i.hg, method=opt.pooled)
	i2i.hg	<- tmp[["transm"]]
	idx.A	<- tmp[["idx.A"]]
	idx.C	<- tmp[["idx.C"]]
	#print( i2i.lw[idx.C,,drop=0] )
	#print( x2i.lw[idx.C,,drop=0] )
	#compute biased proportions
	test.biased.H0.A<-	apply(i2i.lw[idx.A,,drop=0],2,mean)/apply(x2i.lw[idx.A,,drop=0],2,mean)	
	test.biased.H1.A<-	apply(i2i.hg[idx.A,,drop=0],2,mean)/apply(x2i.hg[idx.A,,drop=0],2,mean)
	test.biased.H0.C<-	apply(i2i.lw[idx.C,,drop=0],2,mean)/apply(x2i.lw[idx.C,,drop=0],2,mean)	
	test.biased.H1.C<-	apply(i2i.hg[idx.C,,drop=0],2,mean)/apply(x2i.hg[idx.C,,drop=0],2,mean)			
	#print( test.biased.H0.C )
	#stop()
	#plot proportion I->I sampled against sampling fraction for arm A
	f.name<- paste(dir.name,paste("SAMPLINGBIAS_TIPC_A_visitHCC.C",p.prev.instudy.clu.armC,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
	cat(paste("\nplot sampling bias A to\n",f.name))
	pdf(paste(f.name),version="1.4",width=6,height=6)
	ylim<- range(c(test.biased.H0.A,test.biased.H1.A,test.prop0,test.prop1))
	plot(1,1,type='n',xlim=range(s.consent),ylim=ylim, xlab="%consenting to phyl study at HCC",ylab="proportion acute to acute" )
	abline(h=test.prop0, col="red")
	abline(h=test.prop1, col="blue")
	lines(s.consent, test.biased.H0.A, col="red", lty=2)
	lines(s.consent, test.biased.H1.A, col="blue", lty=2)
	legend(x=0.38,y=0.4,bty='n',legend=c("a2a 40%","a2a 10%"), fill=c("blue","red"), border=NA)
	dev.off()
	#plot proportion I->I sampled against sampling fraction for arm C
	f.name<- paste(dir.name,paste("SAMPLINGBIAS_TIPC_C_visitHCC.C",p.prev.instudy.clu.armC,"power",opt.power,"pool",opt.pooled,"sample",opt.sampling,"pwcalc",test.prop0,test.prop1,test.alpha,".pdf",sep='_'),sep='/')
	cat(paste("\nplot sampling bias C to\n",f.name))
	pdf(paste(f.name),version="1.4",width=6,height=6)
	ylim<- range(c(test.biased.H0.C,test.biased.H1.C,test.prop0,test.prop1))
	plot(1,1,type='n',xlim=range(s.consent),ylim=ylim, xlab="%consenting to phyl study at HCC",ylab="proportion acute to acute" )
	abline(h=test.prop0, col="red")
	abline(h=test.prop1, col="blue")
	lines(s.consent, test.biased.H0.C, col="red", lty=2)
	lines(s.consent, test.biased.H1.C, col="blue", lty=2)
	legend(x=0.38,y=0.4,bty='n',legend=c("a2a 40%","a2a 10%"), fill=c("blue","red"), border=NA)
	dev.off()
	
	###############################################################################
	#check that the biased proportions approach the correct ones as the sampling approaches one.
	###############################################################################
	cat("\ncheck that the biased proportions approach the correct ones as the sampling approaches one")
	s.consent<- seq(0.95,1,0.05)		
	inc<- lapply(s.consent,function(x)
			{
				p.lab			<- 1		
				p.consent.coh	<- 1
				p.consent.clu	<- x
				p.vhcc.prev.AB	<- 1
				p.vhcc.inc.AB	<- 1
				p.vhcc.prev.C	<- 1
				p.vhcc.inc.C	<- 1
				p.nocontam	 	<- 1
				tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.highacute,1-p.nocontam)
				a2a.hg			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, rtn.int=!debug,
						p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
						consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab	)
				tipc.p			<- phdes.get.hyp.tipc.probs(popart.tipcp.lowacute,1-p.nocontam)
				a2a.lw			<- popart.get.sampled.acute2acute( 	sites, tipc.p, opt.sampling, rtn.int=!debug,
						p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
						consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab	)																
				list(a2a.lw=a2a.lw, a2a.hg=a2a.hg)				
			})
	names(inc)<- s.consent
	x2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["x2i.s",])
	i2i.lw	<- sapply(inc,function(x)		x[["a2a.lw"]]["i2i.s",])	
	x2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["x2i.s",])
	i2i.hg	<- sapply(inc,function(x)		x[["a2a.hg"]]["i2i.s",])		
	test.biased.H0	<- apply(i2i.lw,2,mean)/apply(x2i.lw,2,mean)
	test.biased.H1	<- apply(i2i.hg,2,mean)/apply(x2i.hg,2,mean)
	#plot proportion I->I sampled against sampling fraction
	f.name<- paste(dir.name,paste("SAMPLINGBIAS_TIPC_approacges_one.pdf",sep='_'),sep='/')
	cat(paste("\nplot sampling bias approaches one to\n",f.name))
	pdf(paste(f.name),version="1.4",width=6,height=6)
	ylim<- range(c(test.biased.H0,test.biased.H1,test.prop0,test.prop1))
	plot(1,1,type='n',xlim=range(s.consent),ylim=ylim, xlab="%consenting to phyl study at HCC",ylab="proportion acute to acute" )
	abline(h=test.prop0, col="red")
	abline(h=test.prop1, col="blue")
	lines(s.consent, test.biased.H0, col="red", lty=2)
	lines(s.consent, test.biased.H1, col="blue", lty=2)
	legend(x=0.38,y=0.4,bty='n',legend=c("a2a 40%","a2a 10%"), fill=c("blue","red"), border=NA)
	dev.off()
	###############################################################################
	#check that the x2i's are all consistent -- we have 3 calculations
	###############################################################################
	cat("\nccheck that the x2i's are all consistently calculated")
	x2i<- sapply(s.consent,function(x)
			{
				p.lab			<- 1			
				p.consent.coh	<- 1
				p.consent.clu	<- x
				p.vhcc.prev.AB	<- 1
				p.vhcc.inc.AB	<- 1
				p.vhcc.prev.C	<- 1
				p.vhcc.inc.C	<- 1				
				popart.get.sampled.transmissions(	sites, opt.sampling, rtn.int=!debug,
						p.vhcc.prev.AB=p.vhcc.prev.AB, p.vhcc.prev.C=p.vhcc.prev.C, p.vhcc.inc.AB=p.vhcc.inc.AB, p.vhcc.inc.C=p.vhcc.inc.C, 
						consent.PC=p.consent.coh, consent.HCC=p.consent.clu, p.lab=p.lab, p.community=p.nocontam
				)																				
			})
	colnames(x2i)<- s.consent
	
	sapply(seq_len(nrow(x2i)),function(i)
			{
				if(any(round(x2i.lw[i,],d=3)!=round(x2i.hg[i,],d=3)))
					stop("x2i.lw and x2i.hg different ?")
				if(any(round(x2i[i,],d=3)!=round(x2i.hg[i,],d=3)))
					stop("x2i and x2i.hg different ?")				
			})
	stop()	
}

