#setwd("/Users/cfraser/Dropbox/PROJECTS/POPART/Phylogenetics")
sites <- read.csv("triplet_summary_table_121212.csv")

D.study=3 #years

simul<-sites[sites$triplet %in% c(1,4,5,6),] # select studies for phylogenetics
#in ZA chose small high prevalence triplets outside of Lusaka
#5 is Khayelitsha triplet in SA 
#6 is High prevalence triplet in SA


N <- length(simul[,1]) # Number of communities

# randomise communities arms
simul$random<-runif(N)
simul$arm.code<-unlist(tapply(simul$random,simul$triplet.id,rank))
simul$arm<-ifelse(simul$arm.code==1,"A",simul$arm.code)
simul$arm<-ifelse(simul$arm.code==2,"B",simul$arm)
simul$arm<-ifelse(simul$arm.code==3,"C",simul$arm)
drops <- c("random","arm.code")
simul<-simul[,!names(simul) %in% drops]
simul$inc.rate<-sapply(simul$arm,function(x){(x %in% "A")*0.0056+(x %in% "B")*0.01+(x %in% "C")*0.013})
#####

simul$n.adults<-rbinom(N,simul$popsize,ifelse(simul$country==1,0.5,0.6))
simul$n.prev<-rbinom(N,simul$n.adults,simul$hivcomb/100)
simul$n.on.art<-rbinom(N,simul$n.prev,simul$artadjust/100)
simul$n.not.art<-simul$n.prev-simul$n.on.art

simul$n.inc<-rbinom(N,simul$n.adults-simul$n.prev,D.study*simul$inc.rate)
simul$n.neg<-with(simul,n.adults-n.prev-n.inc)

PC.size<-2500
simul$p.in.PC<-PC.size/simul$n.adults

simul$PC.on.art<-rbinom(N,simul$n.on.art,simul$p.in.PC)
simul$PC.not.art<-rbinom(N,simul$n.not.art,simul$p.in.PC)
simul$PC.inc<-rbinom(N,simul$n.inc,simul$p.in.PC)
simul$PC.neg<-PC.size-simul$PC.on.art-simul$PC.not.art-simul$PC.inc


p.community<-0.85 # proportion of infections that come from within the community

p.lab<-1.0 # proportion of isolates that make it through to full genomes

v_prev_AB<-0.95 # proportion of initially +ve individuals who visit HCC at some point in 3 year period in Arms A & B
v_prev_C<-0.5  # proportion of initially +ve individuals who visit HCC at some point in 3 year period in Arm C
v_inc_AB<-0.8 # proportion of incident cases who visit HCC at some point in 3 year period in Arms A and B
v_inc_C<-0.25 # proportion of incident cases who visit HCC at some point in 3 year period in Arm C

simul$visit.prev<-sapply(simul$arm,function(x){(x %in% c("A","B"))*v_prev_AB+(x %in% "C")*v_prev_C})
simul$visit.inc<-sapply(simul$arm,function(x){(x %in% c("A","B"))*v_inc_AB+(x %in% "C")*v_inc_C})

consent.PC<-0.9 # consent rate to phylogenetics in population cohort
consent.HCC<-0.5 # consent rate to phylogenetics in health care centres

simul$seq.PC.prev<-floor(simul$PC.not.art*consent.PC*p.lab)
simul$seq.nonPC.prev<-floor((simul$n.not.art-simul$PC.not.art)*simul$visit.prev*consent.HCC*p.lab)

simul$seq.PC.inc<-floor(simul$PC.inc*consent.PC*p.lab)
simul$seq.nonPC.inc<-floor((simul$n.inc-simul$PC.inc)*simul$visit.inc*consent.HCC*p.lab)

simul$seq.prev=simul$seq.PC.prev+simul$seq.nonPC.prev
simul$seq.inc=simul$seq.PC.inc+simul$seq.nonPC.inc

simul$seq.prev.coverage=simul$seq.prev/simul$n.prev

simul$linked.incident=floor(simul$seq.inc*simul$seq.prev.coverage*p.community)

### calculate mean 

m.simul<-sites[sites$triplet %in% c(1,4,5,6),] # select studies for phylogenetics
m.simul$inc.rate<-(1/3)*(0.0056+0.01+0.013)

m.simul$n.adults<-m.simul$popsize*ifelse(simul$country==1,0.5,0.6)
m.simul$n.prev<-m.simul$n.adults*m.simul$hivcomb/100
m.simul$n.on.art<-m.simul$n.prev*simul$artadjust/100
m.simul$n.not.art<-m.simul$n.prev-m.simul$n.on.art

m.simul$n.inc<-(m.simul$n.adults-m.simul$n.prev)*D.study*m.simul$inc.rate
m.simul$n.neg<-with(m.simul,n.adults-n.prev-n.inc)

m.simul$p.in.PC<-PC.size/m.simul$n.adults

m.simul$PC.on.art<-m.simul$n.on.art*m.simul$p.in.PC
m.simul$PC.not.art<-m.simul$n.not.art*m.simul$p.in.PC
m.simul$PC.inc<-m.simul$n.inc*m.simul$p.in.PC
m.simul$PC.neg<-PC.size-m.simul$PC.on.art-m.simul$PC.not.art-m.simul$PC.inc

m.simul$visit.prev<-(1/3)*(2*v_prev_AB+v_prev_C)
m.simul$visit.inc<-(1/3)*(2*v_inc_AB+v_inc_C)

m.simul$seq.PC.prev<-(m.simul$PC.on.art+m.simul$PC.not.art)*consent.PC*p.lab
m.simul$seq.HCC.prev<-(m.simul$n.on.art+m.simul$n.not.art)*consent.HCC*p.lab
m.simul$seq.nonPC.prev<-(m.simul$n.not.art-m.simul$PC.not.art)*m.simul$visit.prev*consent.HCC*p.lab

m.simul$seq.PC.inc<-m.simul$PC.inc*consent.PC*p.lab
m.simul$seq.HCC.inc<-m.simul$n.inc*m.simul$visit.inc*consent.HCC*p.lab
m.simul$seq.nonPC.inc<-(m.simul$n.inc-m.simul$PC.inc)*m.simul$visit.inc*consent.HCC*p.lab

m.simul$seq.prev=m.simul$seq.PC.prev+m.simul$seq.nonPC.prev
m.simul$seq.inc=m.simul$seq.PC.inc+m.simul$seq.nonPC.inc

m.simul$seq.prev.coverage=m.simul$seq.prev/m.simul$n.prev

m.simul$linked.incident=m.simul$seq.inc*m.simul$seq.prev.coverage*p.community

