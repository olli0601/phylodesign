#! /Library/Frameworks/R.framework/Versions/3.1/Resources/bin/Rscript
#--DSCR------- #! /opt/apps/R-2.15.1/lib64/R/bin/Rscript
#--CX1-------- #! /apps/R/2.13.0/lib64/R/bin/Rscript
###############################################################################
#
#
# Author: oliver ratmann
# file: tipc.startme.R
#
# usage from R:
#> setwd("/Users/Oliver/workspace_sandbox/popartlib/"); source("src_tipclust/tipc.startme.R")
# usage from bash:
#> src_tipclust/tipc.startme.R --help
#
#
# Installation instructions:
#	1 make sure the first line in this file points to your Rscript
#	2.1	create a directory CODE.HOME and set the CODE.HOME variable below to this path
#	2.2	create CODE.HOME/src_tipclust and copy all the R files into this directory
#	2.3 create a directory HOME and set the HOME variable below to this path
#
# How to run popart power calculations
#	1. open a terminal 
#	2.1 	cd to CODE.HOME/src_tipclust
#	2.2		for the link power calculations, always run ./tipc.startme.R -pPOPART.POWER.LINK.CONSENT
#	2.3		for the tip cluster power calculations, always run ./tipc.startme.R -pPOPART.POWER.TIPC.CONSENT
#	2.4		this will run a standard parameterization for the power calculation
#	2.5		to change the standard parameterization, command line options are available, see -help.
#
###############################################################################
args <- commandArgs()
if(!any(args=='--args'))
	args<- vector("numeric",0)
if(any(args=='--args'))
	args<- args[-(1:match("--args", args)) ]

CODE.HOME<<- "/Users/Oliver/workspace_sandbox/popartlib"
#CODE.HOME<<- "/home/koelle/or7/libs/popartlib"
#CODE.HOME<<- "/work/or105/libs/popartlib"
CODE.TIPC<<- "src_tipclust"
HOME<<- "/Users/Oliver/workspace_sandbox/popart"
#HOME<<- "/home/koelle/or7/popart"
#HOME<<- "/work/or105/popart"
DATA<<- paste(HOME,"data",sep='/')
prog<- "prj.popart.powercalc_link_consenting"
prog<- "prj.plotfisherhettransm"
###############################################################################
if(length(args) && !is.loaded("tipc_tabulate_after_sample"))
{
	file<- paste(CODE.HOME,"src_tipclust",paste("libtipcr",.Platform$dynlib.ext,sep=''),sep='/')
	cat(paste("\nloading",file,'\n',sep=' '))
	dyn.load(file)
}
cat(paste("is.loaded('tipcr')->",is.loaded("tipc_tabulate_after_sample"),'\n'))
###############################################################################
function.list<-list.files(path = paste(CODE.HOME,CODE.TIPC,sep='/'), pattern = ".R$", all.files = FALSE,
		full.names = TRUE, recursive = FALSE)
function.list<- function.list[-which(sapply(function.list,function(n){identical(n, paste(CODE.HOME,'/',CODE.TIPC,'/',"tipc.startme.R",sep='') )}))]
#sapply(function.list,print)
sapply(function.list,function(x) source(x,echo=FALSE,print.eval=FALSE, verbose=FALSE))
###############################################################################
my.mkdir(HOME,"data")
my.mkdir(HOME,"pdf")
my.mkdir(HOME,"script")


TIPC.DEBUG<<- 0
###############################################################################
if(length(args))
{
	tmp<- na.omit(sapply(args,function(arg)
					{
						switch(substr(arg,2,4),
								exe= return(substr(arg,5,nchar(arg))),
								NA)
					}))
	if(length(tmp)!=0)
	{
		if(length(tmp)>1) stop("tipc.startme.R: duplicate -exe")
		else prog<- switch(tmp[1],
					TEST= "prj.test",
					SIMU.DATA= "prj.simudata",
					ACUTE.LKL= "prj.acute.loglklsurface",
					ACUTE.ABC= "prj.acutesampling.rejabc",
					WH.SLEEPER= "prj.wh.sleeper")
	}
	tmp<- na.omit(sapply(args,function(arg)
					{
						switch(substr(arg,2,6),
								debug= 1,
								NA)
					}))
	if(length(tmp)!=0)	TIPC.DEBUG<<- tmp[1]
		
	argv<- args
}
###############################################################################
if(TIPC.DEBUG)	options(error= my.dumpframes)	
cat(paste("\ntipc: ",ifelse(TIPC.DEBUG,"debug",""),"call",prog))
do.call(prog,list()) 	
cat("\ntipc: ",ifelse(TIPC.DEBUG,"debug","")," end\n")
